# Quanthon

A minimal Python library for quantum computing.

## Installation

Using PIP:
```sh
pip3 install Quanthon
```

## Get Started

Start!
