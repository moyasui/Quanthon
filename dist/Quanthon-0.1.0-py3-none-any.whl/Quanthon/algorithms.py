'''Doc:
    VQE,
    UCCVQE,
    ADAPT-VQE'''